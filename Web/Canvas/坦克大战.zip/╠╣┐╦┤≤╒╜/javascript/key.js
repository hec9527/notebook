/**
 * 监听键盘按键操作
 */

var key=(function(){
    return 1;
})