/**
 * 碰撞检测
 */

var event=(function(){
    var checkTouch=function(obj1,obj2){
        
    }
    return checkTouch;
})
